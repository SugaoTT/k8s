#!/bin/bash

set -euo pipefail

bash join-worker.sh
